/**
 * Events emitted by the GridLayout component
 */
export enum EDragEvent {
  DRAG_MOVE = `dragmove`,
  DRAG_START = `dragstart`,
  DRAG_END = `dragstart`
}
