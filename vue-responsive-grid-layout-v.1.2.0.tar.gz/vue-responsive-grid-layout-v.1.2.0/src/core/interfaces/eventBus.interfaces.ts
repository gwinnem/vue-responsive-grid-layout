export interface IEventsData {
  eventType: string | symbol;
  h: number;
  i: string | number;
  w: number;
  x: number;
  y: number;
}
