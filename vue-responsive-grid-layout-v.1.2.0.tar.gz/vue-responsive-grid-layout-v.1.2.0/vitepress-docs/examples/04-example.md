# Multiple Grid layout's
This is a simplified version of this functionality.
<br/>
***Some refactoring is needed to be able to have it work with different layouts.***

<CustomComponent/>

<script setup>
import CustomComponent from './components/04-example.vue';
</script>
