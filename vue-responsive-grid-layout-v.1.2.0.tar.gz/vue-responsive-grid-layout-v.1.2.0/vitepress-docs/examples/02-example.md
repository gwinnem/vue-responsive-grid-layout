# Dragging is bound to GridLayout container

<CustomComponent/>

<script setup>
import CustomComponent from './components/02-example.vue';
</script>
