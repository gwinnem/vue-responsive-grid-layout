# Mirrored / Right to Left layout.

<CustomComponent/>

<script setup>
import CustomComponent from './components/06-example.vue';
</script>
