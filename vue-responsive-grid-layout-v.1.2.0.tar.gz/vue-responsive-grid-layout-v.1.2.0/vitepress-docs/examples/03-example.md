# Drag, Drop and resize events

<CustomComponent/>

<script setup>
import CustomComponent from './components/03-example.vue';
</script>
