# Add default border-radius.
The GridItem has a property for adding a 12px border-radius to it.
<br/>
Select the useBorderRadius to show it.

<CustomComponent/>

<script setup>
import CustomComponent from './components/14-example.vue';
</script>
