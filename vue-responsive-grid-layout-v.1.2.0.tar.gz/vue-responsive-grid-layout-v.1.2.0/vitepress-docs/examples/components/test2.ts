// @ts-ignore
import type { TLayout } from 'vue-ts-responsive-grid-layout';

export const testData2: TLayout = [
  {
    h: 2,
    i: 1,
    w: 1,
    x: 0,
    y: 0,
  },
  {
    h: 4,
    i: 2,
    w: 1,
    x: 1,
    y: 0,
  },
  {
    h: 3,
    i: 3,
    w: 1,
    x: 2,
    y: 0,
  },
];
