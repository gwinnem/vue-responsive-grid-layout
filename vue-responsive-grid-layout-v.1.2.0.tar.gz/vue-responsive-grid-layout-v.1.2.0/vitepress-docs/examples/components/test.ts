// @ts-ignore
import type { TLayout } from 'vue-ts-responsive-grid-layout';

export const testData: TLayout = [
  {
    h: 2,
    i: 1,
    w: 1,
    x: 0,
    y: 2,
  },
  {
    h: 2,
    i: 2,
    w: 1,
    x: 1,
    y: 2,
  },
  {
    h: 2,
    i: 3,
    w: 1,
    x: 2,
    y: 2,
  },
  {
    h: 2,
    i: 4,
    w: 1,
    x: 3,
    y: 2,
  },
  {
    h: 2,
    i: 5,
    w: 1,
    x: 0,
    y: 2,
  },
  {
    h: 2,
    i: 6,
    w: 1,
    x: 1,
    y: 2,
  },
  {
    h: 2,
    i: 7,
    w: 1,
    x: 2,
    y: 2,
  },
  {
    h: 2,
    i: 8,
    w: 1,
    x: 3,
    y: 2,
  },
];
