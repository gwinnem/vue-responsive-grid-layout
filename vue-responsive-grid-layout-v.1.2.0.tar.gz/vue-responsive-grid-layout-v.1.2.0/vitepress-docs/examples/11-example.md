# Drag & Drop from outside the grid.

<CustomComponent/>

<script setup>
import CustomComponent from './components/11-example.vue';
</script>
