# Show Default Close Button
Select the showClosebutton to display the default close button.
Click on the button and the item will be removed from the layout.

<CustomComponent/>

<script setup>
import CustomComponent from './components/13-example.vue';
</script>
