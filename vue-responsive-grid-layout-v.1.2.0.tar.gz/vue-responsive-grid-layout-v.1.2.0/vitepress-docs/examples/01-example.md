# Basic Drag & Resize

<CustomComponent/>

<script setup>
import CustomComponent from './components/01-example.vue';
</script>
