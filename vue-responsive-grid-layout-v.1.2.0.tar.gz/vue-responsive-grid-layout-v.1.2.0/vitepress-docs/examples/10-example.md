# Add / Remove Grid items.
Click on the close button to remove an item. Click on the Add button to an item.

<CustomComponent/>

<script setup>
import CustomComponent from './components/10-example.vue';
</script>
