# Prevent collision

<CustomComponent/>

<script setup>
import CustomComponent from './components/08-example.vue';
</script>
