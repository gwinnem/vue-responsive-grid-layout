---
aside: true
page: true
title: Features
---

# Components

This plugin is exporting the following components:


* `GridLayout`, Defines the main grid layout. 
* `GridItem` Defines an item in the layout. 
* `CustomCloseButton` Customized close button.

