# GridLayout styles

```scss
.vue-grid-layout {
  position: relative;
  transition: height 200ms ease;
}
```
