# GridItem Eventbus Events

## compact


## directionchange


## dragEvent
* Emitted in `handleDrag`, the event handler for drag events.


## resizeEvent


## setBounded


## setColNum


## setDraggable


## setMaxRows


## setResizable


## setRowHeight


## setTransformScale


## updateWidth

