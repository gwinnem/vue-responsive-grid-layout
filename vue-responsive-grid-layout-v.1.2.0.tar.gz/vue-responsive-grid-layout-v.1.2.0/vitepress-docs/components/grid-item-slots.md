# GridItem slots

* __Default slot__.
